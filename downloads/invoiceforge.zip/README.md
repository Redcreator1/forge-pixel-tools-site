# ⚡ InvoiceForge — Générateur de Factures

Un générateur de factures professionnelles complet, en un seul fichier
HTML, avec aperçu, export PDF et calculs automatiques.

## ✨ Fonctionnalités

- Informations émetteur et client (nom, email, adresse, TVA/SIRET)
- Lignes de prestations dynamiques (ajout/suppression illimités)
- Calcul automatique des sous-totaux, TVA (par ligne) et total TTC
- **Multi-devises** : EUR, USD, GBP, CHF, CAD
- Aperçu de la facture en temps réel (modal)
- **Export PDF** en un clic (via html2pdf.js)
- Notes / conditions de paiement / IBAN personnalisables
- Design responsive + styles d'impression dédiés
- Aucune donnée envoyée à un serveur : tout reste dans le navigateur

## 🔗 Dépendance

Ce produit charge la bibliothèque **html2pdf.js** (licence MIT) depuis le
CDN public cdnjs.cloudflare.com, uniquement pour la génération du PDF.
Cela signifie qu'une **connexion internet est nécessaire** au moment de
cliquer sur "Télécharger PDF" (le reste de l'outil fonctionne hors-ligne).

Si vous souhaitez une version 100% hors-ligne (bibliothèque embarquée),
c'est tout à fait possible — n'hésitez pas à demander une adaptation.

## 🚀 Installation / Déploiement

Fichier unique : `index.html`. Aucune installation, aucune compilation.

- **Test local** : ouvrez `index.html` dans votre navigateur.
- **Mise en ligne** : déposez le fichier sur n'importe quel hébergement
  statique (Netlify, Vercel, GitHub Pages, OVH, o2switch, etc.).

## 🎨 Personnalisation

Les couleurs et arrondis sont pilotés par des variables CSS en haut du
fichier (`:root { ... }`) :

```css
--accent: #6366f1;       /* couleur principale */
--accent-hover: #4f46e5; /* couleur au survol */
--radius: 12px;          /* arrondi des cartes */
```

Les valeurs par défaut des champs (nom d'entreprise, email, adresse,
IBAN, devises proposées, taux de TVA par défaut...) sont directement
modifiables dans le HTML (attributs `value="..."`) ou dans la fonction
`addLineItem()` pour le JavaScript.

## ℹ️ À savoir

Le badge d'en-tête affiche **"100% Gratuit • Factures illimitées"** —
c'est un reflet fidèle du fonctionnement réel : aucune limite n'est
appliquée dans le code (tout est traité côté navigateur, sans compte ni
backend). Si vous souhaitez transformer cet outil en produit "freemium"
avec une vraie limite (ex: 3 factures/mois), il faudra ajouter un compteur
côté serveur ou un système de compte — ce template est conçu pour rester
100% autonome par défaut.

## 💡 Idées d'utilisation

- Outil gratuit pour freelances et micro-entrepreneurs (génération de
  notoriété pour un cabinet comptable, une banque en ligne, etc.)
- Module intégré dans un espace client / dashboard existant
- Base de départ pour un SaaS de facturation plus complet

## 📄 Licence

Voir le fichier `LICENSE.txt` pour les conditions d'utilisation.
