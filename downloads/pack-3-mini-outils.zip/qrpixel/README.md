# 📱 QR Pixel — Générateur de QR Codes

Un générateur de QR codes personnalisés, élégant et **100% local** : la
génération du QR code se fait entièrement dans le navigateur, sans aucune
requête vers un serveur externe.

## ✨ Fonctionnalités

- **6 types de contenu** : URL, texte libre, email (avec sujet/corps),
  numéro de téléphone, réseau WiFi (SSID + sécurité + mot de passe),
  carte de visite vCard
- Personnalisation de la **couleur** (palette de presets + sélecteur libre)
- 3 **styles** : carré, arrondi, points
- Taille ajustable (150 à 400px)
- **Export PNG et SVG** (vectoriel, idéal pour l'impression)
- Copie directe dans le presse-papiers
- Design responsive, deux colonnes (réglages / aperçu)

## 🔒 100% local — argument fort pour vos clients

Contrairement à beaucoup d'alternatives gratuites en ligne, **aucune
donnée saisie (URL, mot de passe WiFi, coordonnées vCard...) n'est envoyée
à un serveur tiers**. Toute la génération — y compris l'export SVG — est
calculée localement grâce à une bibliothèque JavaScript embarquée. L'outil
fonctionne même **hors connexion** une fois la page chargée.

C'est un excellent argument de confidentialité à mettre en avant auprès de
vos utilisateurs ou clients (génération de QR codes WiFi pour un commerce,
cartes de visite, etc.).

## 🚀 Installation / Déploiement

Fichier unique : `index.html`. Aucune installation, aucune compilation,
aucun serveur requis.

- **Test local** : ouvrez `index.html` dans votre navigateur (fonctionne
  même en double-cliquant, sans serveur).
- **Mise en ligne** : déposez le fichier sur n'importe quel hébergement
  statique (Netlify, Vercel, GitHub Pages, OVH, o2switch, etc.).

## 🎨 Personnalisation

Les couleurs et arrondis sont pilotés par des variables CSS en haut du
fichier (`:root { ... }`) :

```css
--accent: #6366f1;   /* couleur principale */
--accent2: #10b981;  /* couleur secondaire (dégradé) */
--radius: 14px;      /* arrondi des cartes */
```

La liste des couleurs "presets" et des styles disponibles se trouve
directement dans le HTML et peut être étendue librement.

## 🙏 Crédits / Bibliothèque tierce

La génération des QR codes utilise la bibliothèque **qrcode-generator**
de Kazuhiko Arase, sous licence MIT (incluse et créditée directement dans
le code source). Aucune action n'est requise de votre part : l'attribution
est déjà présente dans `index.html`.

- https://github.com/kazuhikoarase/qrcode-generator

## ℹ️ À savoir

Le bloc "QR Pixel PRO" en bas de page est un **emplacement marketing**
prêt à l'emploi : personnalisez-le, retirez-le, ou utilisez-le pour
promouvoir votre propre offre.

## 💡 Idées d'utilisation

- Générateur de QR codes WiFi pour un café, un hôtel, un commerce
- Générateur de vCard / carte de visite numérique
- Outil gratuit ("lead magnet") sur le site d'une agence ou d'un freelance

## 📄 Licence

Voir le fichier `LICENSE.txt` pour les conditions d'utilisation.
