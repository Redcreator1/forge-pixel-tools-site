# 📦 Pack — 3 Mini-Outils Web Prêts à Déployer

Ce pack regroupe **3 mini-applications web** complètes, en HTML/CSS/JS
"vanilla" (aucun framework, aucune dépendance lourde), chacune livrée en un
seul fichier `index.html` autonome, prête à être déployée immédiatement.

| Outil | Description | Dossier |
|---|---|---|
| 🏷️ **HashCraft** | Générateur de hashtags pour Instagram, TikTok, LinkedIn, X, YouTube | `hashcraft/` |
| ⚡ **InvoiceForge** | Générateur de factures professionnelles avec export PDF | `invoiceforge/` |
| 📱 **QR Pixel** | Générateur de QR codes personnalisés, 100% local (PNG + SVG) | `qrpixel/` |

## 🚀 Pour démarrer

Chaque dossier contient :
- `index.html` — le produit, prêt à l'emploi
- `README.md` — fonctionnalités, personnalisation, dépendances
- `LICENSE.txt` — conditions d'utilisation

Ouvrez simplement le fichier `index.html` de l'outil souhaité dans votre
navigateur, ou déposez le dossier sur un hébergement statique (Netlify,
Vercel, GitHub Pages...).

## 🎨 Points communs

- 100% personnalisable via variables CSS (`:root { ... }`) en haut de
  chaque fichier
- Aucun framework, aucune compilation, aucun backend requis
- Design responsive (mobile / desktop)
- Chaque outil intègre un emplacement "PRO" / marketing personnalisable

## 📄 Licence

Voir le fichier `LICENSE.txt` de chaque outil pour le détail des
conditions d'utilisation. En résumé : utilisation libre dans vos projets
personnels et clients (y compris commerciaux), revente du code source en
tant que template non autorisée.

---
Merci pour votre achat — bonne utilisation ! 🙌
