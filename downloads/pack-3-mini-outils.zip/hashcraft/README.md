# 🏷️ HashCraft — Générateur de Hashtags

Un mini-outil web, élégant et 100% autonome, qui génère des suggestions de
hashtags pertinents à partir d'un simple texte décrivant un contenu, pour
Instagram, TikTok, LinkedIn, X (Twitter) et YouTube.

## ✨ Fonctionnalités

- Génération de hashtags adaptée à **5 plateformes** (Instagram, TikTok,
  LinkedIn, X/Twitter, YouTube)
- **Détection automatique de catégorie** (food, lifestyle, tech, fitness,
  business, art, fashion, gaming, éducation...) à partir du texte saisi
- Sélection interactive des hashtags (clic pour activer/désactiver)
- **Export CSV** et **copier dans le presse-papiers** en un clic
- Statistiques visuelles (nombre de hashtags, portée estimée, sélection)
- Design responsive, dégradé moderne, 100% personnalisable via variables CSS
- **Zéro dépendance externe, zéro backend** — un seul fichier HTML

## 🚀 Installation / Déploiement

Ce produit est un fichier unique : `index.html`. Aucune installation,
aucune compilation, aucun serveur requis.

- **Test local** : ouvrez simplement `index.html` dans votre navigateur.
- **Mise en ligne** : déposez le fichier sur n'importe quel hébergement
  statique (Netlify, Vercel, GitHub Pages, OVH, o2switch, etc.). Avec
  Netlify Drop par exemple, il suffit de glisser-déposer le dossier.

## 🎨 Personnalisation

Tout le thème visuel est piloté par des variables CSS en haut du fichier
(`:root { ... }`) :

```css
--accent: #ec4899;   /* couleur principale */
--accent2: #f97316;  /* couleur secondaire (dégradé) */
--bg: #fafafa;       /* fond de page */
--radius: 14px;      /* arrondi des cartes */
```

Changez simplement ces valeurs pour adapter l'outil à votre charte
graphique ou à celle d'un client.

La base de hashtags par catégorie/plateforme se trouve dans la constante
`hashtagDB` (en JavaScript) : vous pouvez l'enrichir librement avec vos
propres hashtags.

## ℹ️ À savoir

Les indicateurs affichés ("volume", "portée estimée") sont des **estimations
indicatives**, générées de façon procédurale pour donner un ordre de
grandeur visuel — ce n'est pas un branchement sur une API d'analytics réelle.
C'est précisé directement dans l'interface pour rester transparent avec vos
utilisateurs finaux.

Le bloc "HashCraft PRO" en bas de page est un **emplacement marketing**
prêt à l'emploi : personnalisez-le, retirez-le, ou utilisez-le pour
promouvoir votre propre offre.

## 💡 Idées d'utilisation

- Outil gratuit ("lead magnet") sur le site d'une agence social media
- Outil interne pour une équipe marketing/contenu
- Intégration dans un produit ou tableau de bord existant

## 📄 Licence

Voir le fichier `LICENSE.txt` pour les conditions d'utilisation.
